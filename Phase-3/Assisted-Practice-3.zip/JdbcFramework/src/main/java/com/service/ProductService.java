package com.service;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.Product;
import com.dao.ProductDao;

@Service
public class ProductService {

	@Autowired
	ProductDao pd;
	

	public List<Product> findAllProduct()
	{
		List<Product> listOfProduct=pd.viewAllProducts();
		System.out.println("Service Executed");
        return listOfProduct;
		
	}
	
	
}
