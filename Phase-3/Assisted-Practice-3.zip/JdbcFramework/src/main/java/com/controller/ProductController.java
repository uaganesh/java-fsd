package com.controller;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bean.Product;
import com.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService ps;
	
	@RequestMapping(value="findProduct",method = RequestMethod.GET)
	public int displayProducts(HttpServletResponse response, Product product)
	{	   
		try {
			
		
		   PrintWriter pw =response.getWriter();
		   response.setContentType("text/html");
		   List<Product> listofProduct=ps.findAllProduct();
		   pw.println("<table border=1>");
		   pw.println("<tr> <th>Pid</th> <th>Pname</th> <th>Price</th>");
		   Iterator<Product> li=listofProduct.iterator();
		   while(li.hasNext())
		   {
			   Product p=li.next();
			   pw.println("<tr> <td>"+p.getId()+"</td>  <td>"+p.getName()+"</td>  <td>"+p.getPrice()+"</td> </tr> ");
		   }
		   pw.println("</table>");
		   return 0;
		}catch (Exception e) {
			System.out.println(e);
		e.toString();
		return 0;
		}
	}
	
	
	
	
	
	
}
