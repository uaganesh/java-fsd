package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bean.Product;
import com.mysql.cj.protocol.Resultset;

@Repository
public class ProductDao {

	@Autowired
	DataSource ds;
 
	@Autowired
	JdbcTemplate jdbcTemplate;
	
    public List<Product> viewAllProducts() 
	{
     try {
   
     //Class.forName("com.mysql.cj.jdbc.Driver");
     //Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/phasethree","root" , "1234");
    Connection con=ds.getConnection(); 
    PreparedStatement pstmt = con.prepareStatement("select * from product");
	 ResultSet rs = pstmt.executeQuery();
	 List<Product> listOfProducts =new ArrayList<Product>();
	 
	 while(rs.next())
	 { 
		System.out.println("1");
		Product product=new Product();
		System.out.println("2");
		product.setId(rs.getInt("id"));
		System.out.println("3");
		product.setName(rs.getString("pname"));
		System.out.println("4");
		product.setPrice(rs.getInt("price"));
		System.out.println("5");
		listOfProducts.add(product);
	 }
		
	 return listOfProducts;

     } catch (Exception e) {
		// TODO: handle exception
    	 System.out.println(e);
    	 e.toString();
    	 return null;
	}
	}
     

}


