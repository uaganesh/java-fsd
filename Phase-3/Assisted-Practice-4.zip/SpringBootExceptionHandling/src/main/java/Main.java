import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com")
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(Main.class, args);
		System.out.println("Server up");

	}

	//Exception Handlung Example
	//Run localhost:8080/product/0 - Exception Generated
	//Run localhost:8080/product/Any Other VAlue - Gives Product output
	
}
