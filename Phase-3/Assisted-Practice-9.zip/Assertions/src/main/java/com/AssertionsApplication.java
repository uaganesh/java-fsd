package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssertionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssertionsApplication.class, args);
	}

}
