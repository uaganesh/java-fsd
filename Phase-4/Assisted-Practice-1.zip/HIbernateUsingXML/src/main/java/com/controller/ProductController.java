package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.bean.EProduct;

/**
 * Servlet implementation class ProductController
 */
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
			PrintWriter out = response.getWriter();
			Configuration con = new Configuration();
			con.configure("hibernate.cfg.xml");	//load xml file
			SessionFactory sf = con.buildSessionFactory();	//connection con
			Session session = sf.openSession();	//statement or preparedstatement in jdbc
			Transaction tran = session.getTransaction();
			tran.begin();
			String sql = "from EProduct";
			Query query = session.createQuery(sql);
			List l =query.list();
		    System.out.println("Total Number Of Records : "+l.size());
		    Iterator it = l.iterator();	
		    while(it.hasNext())
		    {
		        Object o = (Object)it.next();
		        EProduct p = (EProduct)o;
		        out.println("Product id : "+p.getPid());
		        out.println("Product Name : "+p.getPname());
		        out.println("Product Price : "+p.getPrice());
		        out.println("<br>---------------------------------------------------------------------<br>");
		    }    
			tran.commit();
			session.close();
			
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
