package com.product.details;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RecordServlet
 */
@WebServlet("/RecordServlet")
public class RecordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			// Call Connection Method
			Connection con = DBconnection.getMyConnection();
			// Write sql command
			//int id=Integer.parseInt(request.getParameter("txtno"));
			String str = "select * from product";

			// to execute query create object of Statement
			Statement ps = con.createStatement();
			// get ResultSet
			ResultSet ans = ps.executeQuery(str);
			// next method checks for nextrecord
			PrintWriter out = response.getWriter();
			out.println("<table border=2>");
			out.println("<tr><th>ProductId</th><th>ProductName</th><th>Quantity</th><th>Price</th></tr>");
			// To read values from ResultSet
			while (ans.next()) {
				out.println("<tr>");
				out.print("<td>" + ans.getInt("pid") + "</td>");
				out.print("<td>" + ans.getString("pname") + "</td>");
				out.print("<td>" + ans.getInt("quantity") + "</td>");
				out.print("<td>" + ans.getDouble("price") + "</td>");
				out.println("</tr>");
			}
			out.println("</table>");
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

/*PreparedStatement ps=con.prepareStatement("select * from studentdetails where rollno=? or studname=?");
ps.setInt(1,2);
ps.setString(2,"Leena");
ResultSet rs=ps.executeQuery();*/