package com.ecommerce;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;


public class eproduct {
	private long ID;
    private String name;
    private BigDecimal price;
    private Date dateAdded;
    private List<colors> colors;
    private Collection<screensizes> screensizes;
    private Set<os> os;
    private Set<finance> finance;
    
    public void EProduct() {
            
    }
    
    public long getID() {return this.ID; }
    public String getName() { return this.name;}
    public BigDecimal getPrice() { return this.price;}
    public Date getDateAdded() { return this.dateAdded;}
    public List<colors> getColors() { return this.colors;}
    public Collection<screensizes> getScreensizes() { return this.screensizes;}
    public Set<os> getOs() { return this.os;}
    public Set<finance> getFinance() { return this.finance;}
   

    
    public void setID(long id) { this.ID = id;}
    public void setName(String name) { this.name = name;}
    public void setPrice(BigDecimal price) { this.price = price;}
    public void setDateAdded(Date date) { this.dateAdded = date;}
    public void setColors(List<colors> colors) { this.colors = colors;}
    public void setScreensizes(Collection<screensizes> sizes) { this.screensizes = sizes;}
    public void setOs(Set<os> os) { this.os = os;}
    public void setFinance(Set<finance> finance) { this.finance = finance;}
    


}
