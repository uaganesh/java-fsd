package array;


class Main {
	public void rotateArray(int[] data, int k) {
		if (k > data.length)
			k = k % data.length;
		int[] result = new int[data.length];
		for (int i = 0; i < k; i++) {
			result[i] = data[data.length - k + i];
		}
		int j = 0;
		for (int i = k; i < data.length; i++) {
			result[i] = data[j];
			j++;
		}
		System.arraycopy(result, 0, data, 0, data.length);
	}
}

class ArrayRotate {
	public static void main(String[] args) {
		Main r = new Main();
		int aray[] = { 7,8,9,1,2,4,5,6,3};
		r.rotateArray(aray, 5);
		for (int i = 0; i < aray.length; i++) {
			System.out.print(aray[i] + " ");
		}
	}
}
