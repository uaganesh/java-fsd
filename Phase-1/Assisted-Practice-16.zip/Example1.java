package app;
class MyExp extends Exception{
	   String str1;
	   MyExp(String str2) {
		str1=str2;
	   }
	   public String toString(){ 
		return ("MyException Occurred: "+str1) ;
	   }
	}
	class Example1{
	   public static void main(String args[]){
		try{
			System.out.println("Starting of try block");
			throw new MyExp("This is My error Message");
		}
		catch(MyExp exp){
			System.out.println("Catch Block") ;
			System.out.println(exp) ;
		}
	   }
	}
