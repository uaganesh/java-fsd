package app;
public class RunnableThreadExample implements Runnable{
 
    public static int myCount = 0;
    public RunnableThreadExample(){
         
    }
    public void run() {
        while(RunnableThreadExample.myCount <= 10){
            try{
                System.out.println("Concurrent Thread: "+(++RunnableThreadExample.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in thread: "+iex.getMessage());
            }
        }
    } 
    public static void main(String args[])
    {
        System.out.println("Starting Main Thread...");
        RunnableThreadExample obj = new RunnableThreadExample();
        Thread t = new Thread(obj);
        t.start();
        while(RunnableThreadExample.myCount <= 10){
            try{
                System.out.println("Main Thread: "+(++RunnableThreadExample.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex){
                System.out.println("Exception in main thread: "+iex.getMessage());
            }
        }
        System.out.println("End of Main Thread...");
    }
}
