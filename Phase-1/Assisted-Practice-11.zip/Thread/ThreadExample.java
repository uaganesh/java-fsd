package app;

public class ThreadExample extends Thread {
	
	public void run()
	{
		System.out.println("Concurrent Thread Execution Started");
	}

	public static void main(String[] args) {
		
		ThreadExample obj1=new ThreadExample();
		obj1.start();
	
	}

}
