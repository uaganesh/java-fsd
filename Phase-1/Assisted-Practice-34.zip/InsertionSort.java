package search;

public class InsertionSort{
	

    public static  void main(String[] args){

        int[] arr = {18,11,2,10,12};
        System.out.println("Before Sorting");
	     
	     for(int k=0;k<arr.length;k++)
	     {
	    	 System.out.printf("%d ",arr[k]);
	     }
	     System.out.println("\nAfter Sorting");
        insertionSort(arr);
        for(int i=0;i<arr.length;i++){

            System.out.printf("%d ",arr[i]);

        }
     }
    public static void insertionSort(int[] arr){

    int len = arr.length;
    for(int j=1;j<len;j++){
    int key = arr[j];
    int i=j-1;
    while ((i>-1) && (arr[i]>key)){

        arr[i+1]=arr[i];
        i--;
    }
    arr[i+1]=key;
         }

    }
}


