package search;

public class BubbleSortExample {
	

	    public static void main(String[] args){

	     int[] arr= {28,12,15,5,10};

	     System.out.println("Before Sorting");
	     
	     for(int k=0;k<arr.length;k++)
	     {
	    	 System.out.printf("%d ",arr[k]);
	     }
	     System.out.println("\nAfter Sorting");
	     bubblesort(arr);
	     
	     for(int i=0;i<arr.length;i++){

	        System.out.printf("%d ",arr[i]);
	        }
	    }

	    public static void bubblesort(int[] arr){
	        int leng = arr.length;
	        int temp = 0;
	        for(int i=0;i<leng;i++)
	        {
	            for (int j=1;j<(leng);j++)
	            {
	                if(arr[j-1]>arr[j])
	                {
	                temp = arr[j-1];
	                arr[j-1]= arr[j];
	                arr[j]= temp;

	                }


	            }

	        }

	    }

	}



