package search;
import java.util.*;

public class BinarySearch {
	

    public static  void main(String[] args){


        int[] arr = {3,6,9,12,15};
        System.out.println("Enter the item to search");
        Scanner s=new Scanner(System.in);
        int search =s.nextInt();
        int arrlength = arr.length;
        binarySearch(arr,0,search,arrlength);
    }

public static void binarySearch(int[] arr, int start, int search, int length){

        int midValue = (start+length)/2;
        while(start<=length){

            if(arr[midValue]<search){

                start = midValue + 1;
            } else if(arr[midValue]==search){
                System.out.println("Element found at index :"+midValue);
                break;
            }else {

                length=midValue-1;
            }
            midValue = (start+length)/2;
        }
            if(start>length){

                System.out.println("Element is not found");
            }

}

}

