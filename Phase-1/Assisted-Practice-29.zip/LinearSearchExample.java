package search;
import java.util.*;
class LinearSearchExample {
	 public static void main(String[] args){

	        int[] arr = {12,25,28,36,58};

	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the element to find");
	        int searchValue = sc.nextInt();
	            int result = (int) linearsearchitem(arr,searchValue);

	            if(result==-1){

	                System.out.println("Element not in the array");
	            } else {

	                System.out.println("Element found at "+result+" and the search key is "+arr[result]);
	            }


	        }
	 public static int linearsearchitem(int arr[], int x) {

		    int arrlength = arr.length;
		    for (int i = 0; i < arrlength - 1; i++) {

		        if (arr[i] == x) {

		            return i;

		         }
		     }

		            return -1;

		   }

		}
